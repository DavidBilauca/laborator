﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Auth;
using Microsoft.WindowsAzure.Storage.Table;

namespace Lab4
{
    public class AzureStorageManager 
    {
        public static CloudTable AuthTable()
        {
            string accountName = "bilaucadavid00datc";
            string accountKey = "bMHLHnkGU4pt3DQS+YzBLkShqBW53rW7a6LBPOjRunacgYDs8SN91ZJ8knwFOUwTtEd4ojYoCpl+ZmOLeyXNFQ==";
            try {
                StorageCredentials creds = new StorageCredentials(accountName,accountKey);
                CloudStorageAccount account = new CloudStorageAccount(creds, useHttps: true);
                CloudTableClient client = account.CreateCloudTableClient();
                CloudTable table = client.GetTableReference("StudentEntity");

                return table;
            }
            catch
            {
                return null;
            }
        }

    }
}
