﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Lab4.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentEntitiesController : ControllerBase
    {
        // GET: api/<StudentEntitiesController>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/<StudentEntitiesController>/5
        [HttpGet("{id}")]
        public string Get(string partitionKey,string rowKey)
        {
            CloudTable table = AzureStorageManager.AuthTable();
            TableOperation entity = TableOperation.Retrieve<StudentEntity>(partitionKey,rowKey);

            //TableResult result = table.ExecuteAsync(entity);

            //StudentEntity student = result.;
            //Console.WriteLine($"{student.ToString()}\n");

            if (result.Result != null)
            {
                return ((StudentEntity)result.Result).ToString();
            }
            else
            {
                return "esec";
            }
        }

        // POST api/<StudentEntitiesController>
        [HttpPost]
        public bool Post(int id,string nume,string prenume,int anStudiu,string universitatea,string facultatea)
        {
            CloudTable table = AzureStorageManager.AuthTable();
            var newEntity = new StudentEntity()
            {
                PartitionKey = universitatea,
                RowKey = id.ToString(),
                Nume=nume,
                Prenume=prenume,
                AnStudiu=anStudiu,
                Facultatea=facultatea
            };

            TableOperation insert = TableOperation.Insert(newEntity);
            try
            {
                table.ExecuteAsync(insert);
                return true;
            }
            catch (Exception e)
            {
                return false;
            }

        }

        // PUT api/<StudentEntitiesController>/5
        [HttpPut("{id}")]
        public bool Put(int id, string nume, string prenume, int anStudiu, string universitatea, string facultatea)
        {
            CloudTable table = AzureStorageManager.AuthTable();
            StudentEntity student = new StudentEntity()
            {
                PartitionKey = universitatea,
                RowKey = id.ToString(),
                Nume = nume,
                Prenume = prenume,
                AnStudiu = anStudiu,
                Facultatea = facultatea
            };

            TableOperation replace = TableOperation.Replace(student);
            try
            {
                table.ExecuteAsync(replace);
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        // DELETE api/<StudentEntitiesController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            CloudTable table = AzureStorageManager.AuthTable();

            TableOperation entity = TableOperation.Delete();
        }
    }
}
