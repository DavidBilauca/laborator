﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Auth;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FunctionApp1
{
    public class AzureStorageManager
    {
        public static CloudTable AuthTable()
        {
            string accountName = "storageaccountbilaubfaf";
            string accountKey = "hLbBr/4O0OERnHU7lT8YVM1j13rRTZ+iCjY+OOYUtozrZMAEmAF6iRo9fjXMK9C5PWv88jDGAFUz9wi1IYGgsQ==";
            try
            {
                StorageCredentials creds = new StorageCredentials(accountName, accountKey);
                CloudStorageAccount account = new CloudStorageAccount(creds, useHttps: true);
                CloudTableClient client = account.CreateCloudTableClient();
                CloudTable table = client.GetTableReference("StudentEntity");

                return table;
            }
            catch
            {
                return null;
            }
        }

    }
}
