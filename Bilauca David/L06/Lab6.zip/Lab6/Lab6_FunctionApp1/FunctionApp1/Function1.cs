using System;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Azure.Storage.Queues;
using Azure.Storage.Queues.Models;
using Azure.Storage;
using Azure.Core;
using System.Configuration;
using System.Text.Json;
using System.IO;
using Microsoft.WindowsAzure.Storage.Table;

namespace FunctionApp1
{
    
        public static class Function1
        {
            public const string connectionString = "DefaultEndpointsProtocol=https;AccountName=storageaccountbilaubfaf;AccountKey=hLbBr/4O0OERnHU7lT8YVM1j13rRTZ+iCjY+OOYUtozrZMAEmAF6iRo9fjXMK9C5PWv88jDGAFUz9wi1IYGgsQ==;EndpointSuffix=core.windows.net";
            public const string queueName = "lab6-queue1";

            [Function("Function1")]
            public static void Run([QueueTrigger(queueName, Connection = connectionString)]
            string myQueueItem,
                FunctionContext context)
            {
                var logger = context.GetLogger("Function1");
                logger.LogInformation($"C# Queue trigger function processed: {myQueueItem}");

                CloudTable table = AzureStorageManager.AuthTable();
                QueueClient queue1 = new QueueClient(connectionString, queueName);
                QueueMessage qMessage;

            qMessage = queue1.ReceiveMessage();
            StudentEntity student = new StudentEntity();
            student = JsonSerializer.Deserialize<StudentEntity>(qMessage.ToString());
            TableOperation insert = TableOperation.Insert(student);
            table.ExecuteAsync(insert);
            queue1.DeleteMessage(qMessage.MessageId, qMessage.PopReceipt);

            /*
            do
            {
                qMessage = queue1.ReceiveMessage();
                if (qMessage == null)
                {
                    break;
                }
                StudentEntity student = new StudentEntity();
                student = JsonSerializer.Deserialize<StudentEntity>(qMessage.ToString());
                TableOperation insert = TableOperation.Insert(student);
                table.ExecuteAsync(insert);

                queue1.DeleteMessage(qMessage.MessageId, qMessage.PopReceipt);
            } while (true);
            */
        }
        }
}
