﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.Json;
using System.IO;
using Azure.Storage.Queues;
using Azure.Storage.Queues.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Lab4.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentEntitiesController : ControllerBase
    {
        CloudTable table;
        private const string connectionString = "DefaultEndpointsProtocol=https;AccountName=storageaccountbilaubfaf;AccountKey=hLbBr/4O0OERnHU7lT8YVM1j13rRTZ+iCjY+OOYUtozrZMAEmAF6iRo9fjXMK9C5PWv88jDGAFUz9wi1IYGgsQ==;EndpointSuffix=core.windows.net";
        private const string queueName = "lab6-queue1";

        // GET: api/<StudentEntitiesController>
        [HttpGet]
        public async Task<StudentEntity> GetAsync(string partitionKey, string rowKey)
        {
            table = AzureStorageManager.AuthTable();

            var query = TableOperation.Retrieve<StudentEntity>(partitionKey, rowKey);

            var result = await table.ExecuteAsync(query);

            return (StudentEntity)result.Result;
        }



        // GET api/<StudentEntitiesController>/5
        [HttpGet("{id}")]
        public async Task<List<StudentEntity>> GetAllAsync()
        {
            table = AzureStorageManager.AuthTable();
            var students = new List<StudentEntity>();


            TableQuery<StudentEntity> query =
                new TableQuery<StudentEntity>();
                //.Where(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, universitate));

            TableContinuationToken token = null;
            do
            {
                TableQuerySegment<StudentEntity> resultSegment = await table.ExecuteQuerySegmentedAsync(query, token);
                token = resultSegment.ContinuationToken;

                students.AddRange(resultSegment.Results);

            } while (token != null);

            return students;
        }



        // POST api/<StudentEntitiesController>
        [HttpPost]
        public void Post(int id,string nume,string prenume,int anStudiu,string universitatea,string facultatea)
        {
            CloudTable table = AzureStorageManager.AuthTable();
           
            var newEntity = new StudentEntity()
            {
                PartitionKey = universitatea,
                RowKey = id.ToString(),
                Nume=nume,
                Prenume=prenume,
                AnStudiu=anStudiu,
                Facultatea=facultatea
            };

            string jsonString;
            jsonString = JsonSerializer.Serialize<StudentEntity>(newEntity);
            QueueClient queue1 = new QueueClient(connectionString,queueName);
            queue1.SendMessage(jsonString);
            /*
            TableOperation insert = TableOperation.Insert(newEntity);
            try
            {
                table.ExecuteAsync(insert);
                return true;
            }
            catch (Exception e)
            {
                return false;
            }*/

        }



        // PUT api/<StudentEntitiesController>/5
        [HttpPut("{id}")]
        public bool Put(int id, string nume, string prenume, int anStudiu, string universitatea, string facultatea)
        {
            CloudTable table = AzureStorageManager.AuthTable();
            StudentEntity student = new StudentEntity()
            {
                PartitionKey = universitatea,
                RowKey = id.ToString(),
                Nume = nume,
                Prenume = prenume,
                AnStudiu = anStudiu,
                Facultatea = facultatea
            };

            TableOperation replace = TableOperation.Replace(student);
            try
            {
                table.ExecuteAsync(replace);
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        // DELETE api/<StudentEntitiesController>/5
        [HttpDelete("{id}")]
        public async Task<StudentEntity> DeleteAsync(string partitionKey,string rowKey)
        {
           table = AzureStorageManager.AuthTable();

            var query = TableOperation.Retrieve<StudentEntity>(partitionKey, rowKey);

            var result = await table.ExecuteAsync(query);

            var deletionResult = await table.ExecuteAsync(TableOperation.Delete((StudentEntity)result.Result));
            return (StudentEntity)deletionResult.Result;
        }

       

    }
}
