﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lab4
{
    public class Disciplina
    {
        public string Denumire { get; set; }

        public int[] Note { get; set; }


    }
}
