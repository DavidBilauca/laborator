﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;

namespace Lab4
{
    public class StudentEntity : TableEntity
    {
        public int Id { get; set; }
        public string Nume { get; set; }
        public string Prenume { get; set; }
        public int AnStudiu { get; set; }
        public string Universitatea { get; set; }
        public string Facultatea { get; set; }

        
        public override string ToString()
        {
            return $"{Universitatea}, {Id}, {Nume}, {Prenume}, {AnStudiu}, {Facultatea}";
        }

    }
}
