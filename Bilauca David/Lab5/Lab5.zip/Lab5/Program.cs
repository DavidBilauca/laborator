﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Auth;
using Microsoft.WindowsAzure.Storage.Table;

namespace Lab5
{
    class Program
    {

        private static CloudTable _studentsTable;
        private static CloudTable _studentMetricsTable;

        static async Task Main(string[] args)
        {
            _studentsTable = AuthTable("StudentEntity"); 
            _studentMetricsTable = AuthTable("StudentMetricsEntity");

            List<StudentEntity> listaStudenti;
            string[] universitati = new string[] { "UPT", "UMT" };
            int totalStudents = 0;
            char c = '1';
            
            Console.WriteLine($"{DateTime.Now.ToString("dd.mm.yy")}");


            foreach (string uni in universitati)
            {
                
                listaStudenti = GetAllStudents(uni).Result;
                totalStudents += listaStudenti.Count;
                StudentMetricsEntity entry = new StudentMetricsEntity()
                {
                    PartitionKey = uni,
                    RowKey = DateTime.Now.ToString("dd.MM.yy,hh:mm:ss"),
                    Count = listaStudenti.Count
                };
                 await InsertNewMetric(entry);
                Console.WriteLine("Metrica noua:");
                Console.WriteLine($"Institutia: {entry.Universitatea}, Data masuratorii: {entry.RowKey}, Numar studenti: {entry.Count}\n");
                
            }

            StudentMetricsEntity entry2 = new StudentMetricsEntity()
            {
                PartitionKey = "General",
                RowKey = DateTime.Now.ToString("dd.MM.yy,hh:mm:ss"),
                Count = totalStudents
            };
            await InsertNewMetric(entry2);
            Console.WriteLine("Metrica noua:");
            Console.WriteLine($"Toate institutiile, Data masuratorii: {entry2.RowKey}, Numar studenti: {entry2.Count}\n");
            

            //Console.WriteLine("Hello World!");
        }

        public static async Task<List<StudentEntity>> GetAllStudents(string universitate)
        {
            var students = new List<StudentEntity>();

            TableQuery<StudentEntity> query = new TableQuery<StudentEntity>().Where(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, universitate));

            TableContinuationToken token = null;
            do
            {
                TableQuerySegment<StudentEntity> resultSegment = await _studentsTable.ExecuteQuerySegmentedAsync(query, token);
                token = resultSegment.ContinuationToken;

                students.AddRange(resultSegment.Results);

            } while (token != null);

            return students;
        }

        public static async Task InsertNewMetric(StudentMetricsEntity metric)
        {
            var insertOperation = TableOperation.Insert(metric);

            await _studentMetricsTable.ExecuteAsync(insertOperation);
        }

        public static CloudTable AuthTable(string tableName)
        {
            var account = CloudStorageAccount.Parse("DefaultEndpointsProtocol=https;AccountName=bilaucadavid00datc;AccountKey=bMHLHnkGU4pt3DQS+YzBLkShqBW53rW7a6LBPOjRunacgYDs8SN91ZJ8knwFOUwTtEd4ojYoCpl+ZmOLeyXNFQ==;EndpointSuffix=core.windows.net");
            string accountName = "bilaucadavid00datc";
            string accountKey = "bMHLHnkGU4pt3DQS+YzBLkShqBW53rW7a6LBPOjRunacgYDs8SN91ZJ8knwFOUwTtEd4ojYoCpl+ZmOLeyXNFQ==";
            try
            {
                //StorageCredentials creds = new StorageCredentials(accountName, accountKey);
                //CloudStorageAccount account = new CloudStorageAccount(creds, useHttps: true);
                CloudTableClient client = account.CreateCloudTableClient();
                CloudTable table = client.GetTableReference(tableName);

                return table;
            }
            catch
            {
                Console.WriteLine("Nu s-a putut accesa tabelul:{0}",tableName);
                return null;
            }
        }
    }
}
